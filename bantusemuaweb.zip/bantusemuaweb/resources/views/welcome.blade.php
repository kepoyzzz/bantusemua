@extends('layout')
@section('title')
@section('main')
<html lang="en">
  <head>
    <link rel="stylesheet" type="text/css" href="css/home.css">
  </head>
    <body>
      <div class="jumbotron jumbotron-fluid">
        <div class="container">
          <h1>Welcome Back,</h1>
          <h2>{{Session::get('userName')}}</h2>
        </div>
      </div>
    </body>
</html>
@endsection
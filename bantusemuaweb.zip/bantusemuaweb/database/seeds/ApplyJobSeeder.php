<?php

use Illuminate\Database\Seeder;

class ApplyJobSeeder extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
        //
        
    }
}
